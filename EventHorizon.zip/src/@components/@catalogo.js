import './my-element';
import './simple-greeting';
import './my-element2';
import './tu-element.ts';