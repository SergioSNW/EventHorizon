// // all.js
// // Styles
// // import "bootstrap/dist/css/bootstrap.min.css";   // No lo he instalado
import "../css/app.css";
// import "../css/zz1.sass";
// Scripts - App
import './app.js';
import './prueba1.js';
// import './my-element.js';
// // import '../index.html';
import './my-element.js';
import './simple-greeting.js';